<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Content-Type: application/json; charset=utf-8');
$path=__DIR__.DIRECTORY_SEPARATOR.'result.json';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $status=strtoupper(trim((string)($_POST['status']??'')));
  if (!preg_match('/^[A-Z0-9_]{3,64}$/',$status)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'bad_status']); exit; }
  $detail=preg_replace('/[\x00-\x1F\x7F]/u',' ',(string)($_POST['detail']??''));
  $detail=substr($detail,0,800);
  $data=['ok'=>true,'status'=>$status,'detail'=>$detail,'utc'=>gmdate('c')];
  file_put_contents($path,json_encode($data,JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT),LOCK_EX);
  echo json_encode($data,JSON_UNESCAPED_SLASHES); exit;
}
if (!is_file($path)) { echo json_encode(['ok'=>true,'status'=>'NO_RESULT']); exit; }
readfile($path);
